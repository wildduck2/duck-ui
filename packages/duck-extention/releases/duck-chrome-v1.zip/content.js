(function(){function d(e){if(!e||typeof e!="string"||["chrome://","edge://","about:","moz-extension://","chrome-extension://"].some(o=>e.startsWith(o)))return null;let t=e.trim();/^https?:\/\//i.test(t)||(t="https://"+t);try{return new URL(t).hostname.replace(/^www\./,"")}catch{return null}}function g(e,t){return!e||!t?"":[`@import url('${t}');`,"*, *::before, *::after {",`  font-family: '${e.family}', sans-serif !important;`,"}"].join(`
`)}function f(e,t){let o=document.getElementById("gentleduck-font-link");o&&o.remove(),t&&(o=document.createElement("link"),o.id="gentleduck-font-link",o.rel="stylesheet",o.href=t,document.head.appendChild(o));let n=document.getElementById("gentleduck-font-style");n&&n.remove();const i=g(e,t);i&&(n=document.createElement("style"),n.id="gentleduck-font-style",n.textContent=i,document.head.appendChild(n)),e?.family&&console.log("🔥 Gentleduck font applied:",e.family)}function a(){const e=document.getElementById("gentleduck-font-link");e&&e.remove();const t=document.getElementById("gentleduck-font-style");t&&t.remove()}function l(){const e=d(window.location.href);if(!e){a();return}chrome.storage.sync.get(["gentleduck_domainFonts","gentleduck_disabledDomains"],t=>{const o=t.gentleduck_domainFonts||{};if((t.gentleduck_disabledDomains||[]).includes(e)){a();return}const n=o[e];if(!n){a();return}const i=`https://fonts.googleapis.com/css2?family=${n.family.replaceAll(" ","+")}:wght@${n.variants.join(";")}&display=swap`;f(n,i)})}function u(){if(document.getElementById("gentleduck-toggle-btn"))return;const e=d(window.location.href);if(!e)return;const t=document.createElement("button");t.id="gentleduck-toggle-btn",t.innerHTML="🔤",t.title="Toggle Gentleduck Extension",t.style.cssText=`
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #000;
    color: #fff;
    border: 2px solid #fff;
    cursor: pointer;
    z-index: 999999;
    font-size: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    transition: all 0.2s;
    user-select: none;
    -webkit-user-select: none;
    padding: 0;
    margin: 0;
  `,chrome.storage.sync.get(["gentleduck_disabledDomains"],o=>{const n=(o.gentleduck_disabledDomains||[]).includes(e);c(t,n)}),t.addEventListener("mouseenter",()=>{t.style.transform="scale(1.1)",t.style.boxShadow="0 6px 16px rgba(0, 0, 0, 0.4)"}),t.addEventListener("mouseleave",()=>{t.style.transform="scale(1)",t.style.boxShadow="0 4px 12px rgba(0, 0, 0, 0.3)"}),t.addEventListener("click",()=>{chrome.storage.sync.get(["gentleduck_disabledDomains"],o=>{const n=o.gentleduck_disabledDomains||[],i=n.includes(e),s=i?n.filter(r=>r!==e):[...n,e];chrome.storage.sync.set({gentleduck_disabledDomains:s},()=>{c(t,!i),l()})})}),document.body.appendChild(t)}function c(e,t){t?(e.style.opacity="0.5",e.style.background="#666",e.title="Enable Gentleduck Extension"):(e.style.opacity="1",e.style.background="#000",e.title="Disable Gentleduck Extension")}function m(){if(l(),document.body)u();else{const e=new MutationObserver(()=>{document.body&&(u(),e.disconnect())});e.observe(document.documentElement,{childList:!0,subtree:!0})}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",m):m(),chrome.storage.onChanged.addListener((e,t)=>{if(t==="sync"&&(e.gentleduck_domainFonts||e.gentleduck_disabledDomains)){l();const o=document.getElementById("gentleduck-toggle-btn");if(o){const n=d(window.location.href);n&&chrome.storage.sync.get(["gentleduck_disabledDomains"],i=>{const s=i.gentleduck_disabledDomains||[];c(o,s.includes(n))})}}}),chrome.runtime.onMessage.addListener((e,t,o)=>{if(e.type==="UPDATE_FONT"){l();const n=document.getElementById("gentleduck-toggle-btn");if(n){const i=d(window.location.href);i&&chrome.storage.sync.get(["gentleduck_disabledDomains"],s=>{const r=s.gentleduck_disabledDomains||[];c(n,r.includes(i))})}}})})();
