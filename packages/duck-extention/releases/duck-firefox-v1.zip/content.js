(function(){function c(e){if(!e||typeof e!="string"||["chrome://","edge://","about:","moz-extension://","chrome-extension://"].some(n=>e.startsWith(n)))return null;let t=e.trim();/^https?:\/\//i.test(t)||(t="https://"+t);try{return new URL(t).hostname.replace(/^www\./,"")}catch{return null}}function f(e,t){return!e||!t?"":[`@import url('${t}');`,"*, *::before, *::after {",`  font-family: '${e.family}', sans-serif !important;`,"}"].join(`
`)}function y(e,t){let n=document.getElementById("gentleduck-font-link");n&&n.remove(),t&&(n=document.createElement("link"),n.id="gentleduck-font-link",n.rel="stylesheet",n.href=t,document.head.appendChild(n));let o=document.getElementById("gentleduck-font-style");o&&o.remove();const s=f(e,t);s&&(o=document.createElement("style"),o.id="gentleduck-font-style",o.textContent=s,document.head.appendChild(o)),e?.family&&console.log("🔥 Gentleduck font applied:",e.family)}function m(){const e=document.getElementById("gentleduck-font-link");e&&e.remove();const t=document.getElementById("gentleduck-font-style");t&&t.remove()}function a(){const e=c(window.location.href);if(!e){m();return}chrome.storage.sync.get(["gentleduck_domainFonts","gentleduck_disabledDomains"],t=>{const n=t.gentleduck_domainFonts||{};if((t.gentleduck_disabledDomains||[]).includes(e)){m();return}const o=n[e];if(!o){m();return}const s=`https://fonts.googleapis.com/css2?family=${o.family.replaceAll(" ","+")}:wght@${o.variants.join(";")}&display=swap`;y(o,s)})}function r(){if(document.getElementById("gentleduck-toggle-btn"))return;const e=c(window.location.href);e&&chrome.storage.sync.get(["gentleduck_domainFonts"],t=>{if(!(t.gentleduck_domainFonts||{})[e])return;const n=document.createElement("button");n.id="gentleduck-toggle-btn",n.innerHTML="🔤",n.title="Toggle Gentleduck Extension",n.style.cssText=`
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: #000;
      color: #fff;
      border: 2px solid #fff;
      cursor: pointer;
      z-index: 999999;
      font-size: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      transition: all 0.2s;
      user-select: none;
      -webkit-user-select: none;
      padding: 0;
      margin: 0;
    `,chrome.storage.sync.get(["gentleduck_disabledDomains"],o=>{const s=(o.gentleduck_disabledDomains||[]).includes(e);u(n,s)}),n.addEventListener("mouseenter",()=>{n.style.transform="scale(1.1)",n.style.boxShadow="0 6px 16px rgba(0, 0, 0, 0.4)"}),n.addEventListener("mouseleave",()=>{n.style.transform="scale(1)",n.style.boxShadow="0 4px 12px rgba(0, 0, 0, 0.3)"}),n.addEventListener("click",()=>{chrome.storage.sync.get(["gentleduck_disabledDomains"],o=>{const s=o.gentleduck_disabledDomains||[],i=s.includes(e),d=i?s.filter(l=>l!==e):[...s,e];chrome.storage.sync.set({gentleduck_disabledDomains:d},()=>{u(n,!i),a()})})}),document.body.appendChild(n)})}function u(e,t){t?(e.style.opacity="0.5",e.style.background="#666",e.title="Enable Gentleduck Extension"):(e.style.opacity="1",e.style.background="#000",e.title="Disable Gentleduck Extension")}function g(){if(a(),document.body)r();else{const e=new MutationObserver(()=>{document.body&&(r(),e.disconnect())});e.observe(document.documentElement,{childList:!0,subtree:!0})}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",g):g(),chrome.storage.onChanged.addListener((e,t)=>{if(t==="sync"&&(e.gentleduck_domainFonts||e.gentleduck_disabledDomains)){a();const n=c(window.location.href);if(!n)return;chrome.storage.sync.get(["gentleduck_domainFonts"],o=>{const s=o.gentleduck_domainFonts||{},i=document.getElementById("gentleduck-toggle-btn");s[n]?i?chrome.storage.sync.get(["gentleduck_disabledDomains"],d=>{const l=d.gentleduck_disabledDomains||[];u(i,l.includes(n))}):r():i&&i.remove()})}}),chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type==="UPDATE_FONT"){a();const o=c(window.location.href);if(!o)return;chrome.storage.sync.get(["gentleduck_domainFonts"],s=>{const i=s.gentleduck_domainFonts||{},d=document.getElementById("gentleduck-toggle-btn");i[o]?d?chrome.storage.sync.get(["gentleduck_disabledDomains"],l=>{const k=l.gentleduck_disabledDomains||[];u(d,k.includes(o))}):r():d&&d.remove()})}})})();
